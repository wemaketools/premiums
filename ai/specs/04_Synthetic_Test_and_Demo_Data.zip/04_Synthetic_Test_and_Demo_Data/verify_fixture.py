"""The Brittany POC: reference fixture reconciliations, Python 3 stdlib only."""
import csv, json
from collections import Counter
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).parent
D=ROOT/'01_golden_test_fixture'
get=lambda n:list(csv.DictReader((D/(n+'.csv')).open(encoding='utf-8')))
D2=lambda val:Decimal(str(val))
invoices=get('premium_invoices'); allocations=get('payment_allocations');receipts=get('receipts');claims=get('claims');payments=get('claim_payments')
assert len(invoices)==6
applied=Counter()
for a in allocations:applied[a['invoice_id']]+=D2(a['allocated_amount'])
unpaid={v['invoice_id']:D2(v['issued_amount'])-applied[v['invoice_id']] for v in invoices}
assert sum(D2(v['issued_amount']) for v in invoices)==48000
assert sum(applied.values())==14000
assert sum(unpaid.values())==34000
asof='2026-10-21'
assert sum(unpaid[v['invoice_id']] for v in invoices if v['due_date']<asof)==29000
assert sum(D2(r['gross_amount']) for r in receipts if r['received_at'].startswith('2026-10'))==7500
rcpt_allocation=Counter()
for a in allocations:rcpt_allocation[a['receipt_id']]+=D2(a['allocated_amount'])
assert sum(D2(r['gross_amount'])-rcpt_allocation[r['receipt_id']] for r in receipts)==1500
assert len(claims)==6 and sum(v['status']=='OPEN' for v in claims)==5
assert sum(D2(v['paid_amount']) for v in payments if v['status']=='POSTED')==9000
assert sum(D2(v['current_outstanding_reserve']) for v in claims)==68000
assert sum(D2(v['paid_amount']) for v in payments)+sum(D2(v['current_outstanding_reserve']) for v in claims)==77000
assert Counter(v['stage'] for v in claims if v['status']=='OPEN')==Counter({'Assessment':2,'Triage':1,'Approved':1,'New':1})
print('PASS: TEST fixture cash, aging headline, claims position, and stages match expected_metrics.json')
